import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { PlatMap, SHEET_COPY, type SheetId } from "@/components/plat-maps";
import { displayName, LOTS, matches, matchesFilter, sheetOf, type Lot, type LotFilter, type LotStatus } from "@/data/lots";

export const Route = createFileRoute("/")({ component: Home });

const STORAGE_KEY = "magnolia-lot-edits";

function loadLots(): Lot[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return LOTS;
    const saved = JSON.parse(raw) as Lot[];
    const byId = new Map(saved.map((lot) => [lot.id, lot]));
    return LOTS.map((lot) => {
      const next = byId.get(lot.id);
      if (!next) return lot;
      const status: LotStatus =
        next.status === "Empty" || next.status === "Open" || next.status === "Eviction" ? next.status : "Occupied";
      return { ...lot, ...next, id: lot.id, status, bouncedCheck: next.bouncedCheck ?? "", maintenance: next.maintenance ?? "" };
    });
  } catch {
    return LOTS;
  }
}

function printMap(id: SheetId) {
  const root = document.getElementById(`map-${id}`) ?? document.querySelector(".map-stage");
  const svg = root?.querySelector("svg");
  if (!svg) return;
  const css = [...document.styleSheets]
    .map((sheet) => {
      try {
        return [...sheet.cssRules].map((rule) => rule.cssText).join("\n");
      } catch {
        return "";
      }
    })
    .join("\n");
  const page = id === 3 ? "portrait" : "landscape";
  const win = window.open("", "_blank");
  if (!win) return;
  win.document.open();
  win.document.write(`<!doctype html><html><head><title>${SHEET_COPY[id].title}</title><style>
    ${css}
    @page { size: ${page}; margin: 0.4in; }
    html, body { margin: 0; height: auto; background: white; }
    h1 { margin: 0 0 8px; font: 700 16px sans-serif; letter-spacing: 0.08em; text-transform: uppercase; }
    svg { width: 100% !important; height: auto !important; max-height: none !important; display: block; }
    * { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  </style></head><body><h1>${SHEET_COPY[id].title}</h1></body></html>`);
  win.document.close();
  win.document.body.appendChild(win.document.importNode(svg, true));
  const go = () => {
    if (win.closed || win.document.body.dataset.printed === "1") return;
    win.document.body.dataset.printed = "1";
    win.focus();
    win.print();
  };
  win.onload = () => setTimeout(go, 200);
  setTimeout(go, 500);
}

function printMain() {
  const ids = [1, 2, 3] as const;
  const svgs = ids
    .map((id) => document.querySelector(`#map-${id} svg`))
    .filter((node): node is SVGSVGElement => node instanceof SVGSVGElement);
  if (svgs.length === 0) return;
  const css = [...document.styleSheets]
    .map((sheet) => {
      try {
        return [...sheet.cssRules].map((rule) => rule.cssText).join("\n");
      } catch {
        return "";
      }
    })
    .join("\n");
  const win = window.open("", "_blank");
  if (!win) return;
  win.document.open();
  win.document.write(`<!doctype html><html><head><title>Main</title><style>
    ${css}
    @page land { size: landscape; margin: 0.4in; }
    @page port { size: portrait; margin: 0.4in; }
    html, body { margin: 0; height: auto; background: white; }
    h1 { margin: 0 0 8px; font: 700 16px sans-serif; letter-spacing: 0.08em; text-transform: uppercase; }
    section.land { page: land; break-after: page; }
    section.port { page: port; break-after: page; }
    svg { width: 100% !important; height: auto !important; max-height: none !important; display: block; }
    * { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  </style></head><body></body></html>`);
  win.document.close();
  svgs.forEach((svg, index) => {
    const id = ids[index];
    const section = win.document.createElement("section");
    section.className = id === 3 ? "port" : "land";
    const heading = win.document.createElement("h1");
    heading.textContent = SHEET_COPY[id].title;
    section.append(heading, win.document.importNode(svg, true));
    win.document.body.appendChild(section);
  });
  const go = () => {
    if (win.closed || win.document.body.dataset.printed === "1") return;
    win.document.body.dataset.printed = "1";
    win.focus();
    win.print();
  };
  win.onload = () => setTimeout(go, 200);
  setTimeout(go, 500);
}

function Home() {
  const [sheet, setSheet] = useState<SheetId>(1);
  const [main, setMain] = useState(true);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<LotFilter>("all");
  const [selected, setSelected] = useState<string | null>("1");
  const [register, setRegister] = useState(false);
  const [cell, setCell] = useState<{ id: string; field: keyof Lot } | null>(null);

  const [lots, setLots] = useState<Lot[]>(LOTS);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setLots(loadLots());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(lots));
  }, [lots, hydrated]);

  function saveLot(next: Lot) {
    setLots((prev) => prev.map((item) => (item.id === next.id ? next : item)));
  }

  const visible = useMemo(() => {
    return lots.filter((lot) => matchesFilter(lot, filter) && matches(lot, query));
  }, [lots, filter, query]);

  const sig = `${filter}|${query}`;
  const prevSig = useRef(sig);

  useEffect(() => {
    if (prevSig.current === sig) return;
    prevSig.current = sig;
    if (!query.trim() && filter === "all") return;
    if (visible.length === 1) {
      setSelected(visible[0].id);
      const next = sheetOf(visible[0].id);
      if (next) {
        setSheet(next);
        setRegister(false);
        setMain(false);
      } else {
        setRegister(true);
      }
      return;
    }
    const sheets = new Set(visible.map((lot) => sheetOf(lot.id)).filter((n): n is SheetId => n != null));
    if (sheets.size === 1 && visible.length > 0 && visible.every((lot) => sheetOf(lot.id))) {
      setSheet([...sheets][0]);
      setRegister(false);
      setMain(false);
    }
  }, [sig, query, filter, visible]);

  const lot = lots.find((item) => item.id === selected) ?? null;
  const empty = lots.filter((item) => item.status === "Empty").length;
  const notes = lots.filter((item) => item.issues).length;

  return (
    <main className="app">
      <header className="top">
        <div>
          <p className="kicker">Site plan</p>
          <h1>Magnolia Central of Florida Estates</h1>
          <p className="stats">
            {lots.length} records · {empty} empty · {notes} with a note · names from the lot register
          </p>
        </div>
        <input
          className="search"
          value={query}
          placeholder="Lot, name, or address"
          aria-label="Search lots"
          onChange={(e) => setQuery(e.target.value)}
        />
      </header>
      <div className="toolbar">
        <div className="tabs" role="tablist" aria-label="Sheets">
          <button
            className="tab"
            type="button"
            role="tab"
            aria-pressed={!register && main}
            onClick={() => {
              setRegister(false);
              setMain(true);
            }}
          >
            Main
          </button>
          {([1, 2, 3] as const).map((id) => (
            <button
              key={id}
              className="tab"
              type="button"
              role="tab"
              aria-pressed={!register && !main && sheet === id}
              onClick={() => {
                setRegister(false);
                setMain(false);
                setSheet(id);
              }}
            >
              {SHEET_COPY[id].title}
            </button>
          ))}
          <button className="tab" type="button" aria-pressed={register} onClick={() => setRegister(true)}>
            Register
          </button>
        </div>
        <div className="filters">
          {(
            [
              ["all", "All"],
              ["empty", "Empty"],
              ["occupied", "Occupied"],
              ["issues", "Issues"],
              ["renters", "Renters"],
              ["owners", "Owners"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              className="filter"
              type="button"
              aria-pressed={filter === id}
              onClick={() => setFilter(id)}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="legend">
          <span>
            <i className="swatch" /> Occupied
          </span>
          <span>
            <i className="swatch empty" /> Empty
          </span>
          <span>
            <i className="swatch open" /> Office
          </span>
          <span>
            <i className="swatch notes" /> Issues
          </span>
          <span>
            <i className="swatch late" /> Late rent
          </span>
          <span>
            <i className="swatch leak" /> Leak
          </span>
          <span>
            <i className="swatch maint" /> Maintenance
          </span>
          <span>
            <i className="swatch eviction" /> Eviction
          </span>
        </div>
      </div>
      <div className="stage">
        <section className="map-frame">
          {register ? (
            <table className="register">
              <thead>
                <tr>
                  <th>Lot</th>
                  <th>Address</th>
                  <th>Street</th>
                  <th>Name</th>
                  <th>Status</th>
                  <th>Note</th>
                </tr>
              </thead>
              <tbody>
                {lots.map((item) => {
                  const hit = visible.includes(item);
                  return (
                    <tr
                      key={item.id}
                      data-hit={hit}
                      aria-selected={selected === item.id}
                      onClick={() => setSelected(item.id)}
                    >
                      <EditableCell item={item} field="lot" cell={cell} setCell={setCell} onSave={saveLot} />
                      <EditableCell item={item} field="address" cell={cell} setCell={setCell} onSave={saveLot} />
                      <EditableCell item={item} field="street" cell={cell} setCell={setCell} onSave={saveLot} />
                      <EditableCell item={item} field="name" cell={cell} setCell={setCell} onSave={saveLot} display={displayName(item)} />
                      <EditableCell item={item} field="status" cell={cell} setCell={setCell} onSave={saveLot} />
                      <EditableCell item={item} field="issues" cell={cell} setCell={setCell} onSave={saveLot} />
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : main ? (
            <div className="map-stack">
              <div className="main-print">
                <button className="print-map" type="button" onClick={printMain}>
                  Print map
                </button>
              </div>
              {([1, 2, 3] as const).map((id) => (
                <section key={id} id={`map-${id}`} className="map-block">
                  <h2>{SHEET_COPY[id].title}</h2>
                  <PlatMap sheet={id} query={query} filter={filter} selected={selected} lots={lots} onSelect={setSelected} />
                </section>
              ))}
            </div>
          ) : (
            <>
              <p className="sheet-note">{SHEET_COPY[sheet].note}</p>
              <button className="print-map corner" type="button" onClick={() => printMap(sheet)}>
                Print map
              </button>
              <div className="map-stage">
                <div className="map-scaler">
                  <PlatMap sheet={sheet} query={query} filter={filter} selected={selected} lots={lots} onSelect={setSelected} />
                </div>
              </div>
              <button
                className="map-nav prev"
                type="button"
                aria-label="Previous map"
                onClick={() => setSheet(sheet === 1 ? 3 : ((sheet - 1) as SheetId))}
              >
                ‹
              </button>
              <button
                className="map-nav next"
                type="button"
                aria-label="Next map"
                onClick={() => setSheet(sheet === 3 ? 1 : ((sheet + 1) as SheetId))}
              >
                ›
              </button>
            </>
          )}
        </section>
        <LotPanel
          lot={lot}
          onSave={(next) => setLots((prev) => prev.map((item) => (item.id === next.id ? next : item)))}
        />
      </div>
    </main>
  );
}

function EditableCell({
  item,
  field,
  cell,
  setCell,
  onSave,
  display,
}: {
  item: Lot;
  field: keyof Lot;
  cell: { id: string; field: keyof Lot } | null;
  setCell: (next: { id: string; field: keyof Lot } | null) => void;
  onSave: (next: Lot) => void;
  display?: string;
}) {
  const active = cell?.id === item.id && cell.field === field;
  const raw = item[field];
  if (active && field === "status") {
    return (
      <td>
        <select
          className="cell-edit"
          autoFocus
          defaultValue={raw}
          onClick={(e) => e.stopPropagation()}
          onBlur={(e) => {
            const status: LotStatus =
              e.target.value === "Empty" || e.target.value === "Open" || e.target.value === "Eviction"
                ? e.target.value
                : "Occupied";
            onSave({ ...item, status });
            setCell(null);
          }}
          onChange={(e) => {
            const status: LotStatus =
              e.target.value === "Empty" || e.target.value === "Open" || e.target.value === "Eviction"
                ? e.target.value
                : "Occupied";
            onSave({ ...item, status });
            setCell(null);
          }}
        >
          <option>Occupied</option>
          <option>Empty</option>
          <option>Open</option>
          <option>Eviction</option>
        </select>
      </td>
    );
  }
  if (active) {
    return (
      <td>
        <input
          className="cell-edit"
          autoFocus
          defaultValue={raw}
          onClick={(e) => e.stopPropagation()}
          onBlur={(e) => {
            onSave({ ...item, [field]: e.target.value });
            setCell(null);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") e.currentTarget.blur();
            if (e.key === "Escape") setCell(null);
          }}
        />
      </td>
    );
  }
  const text = (display ?? raw).trim();
  return (
    <td
      onClick={(e) => {
        e.stopPropagation();
        setCell({ id: item.id, field });
      }}
    >
      {text || "—"}
    </td>
  );
}

function nameParts(name: string): { first: string; last: string } {
  const raw = name.trim();
  if (!raw) return { first: "", last: "" };
  const comma = raw.indexOf(",");
  if (comma >= 0) return { last: raw.slice(0, comma).trim(), first: raw.slice(comma + 1).trim() };
  return { first: "", last: raw };
}

function joinName(last: string, first: string) {
  const l = last.trim();
  const f = first.trim();
  if (l && f) return `${l}, ${f}`;
  return l || f;
}

function LotPanel({ lot, onSave }: { lot: Lot | null; onSave: (next: Lot) => void }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Lot | null>(null);

  useEffect(() => {
    setEditing(false);
    setDraft(null);
  }, [lot?.id]);

  if (!lot) {
    return (
      <aside className="panel">
        <p className="quiet">Select a lot on the map.</p>
      </aside>
    );
  }
  const where = sheetOf(lot.id);
  if (editing && draft) {
    return (
      <aside className="panel">
        <form
          className="edit-form"
          onSubmit={(e) => {
            e.preventDefault();
            onSave(draft);
            setEditing(false);
          }}
        >
          {RECORD_FIELDS.map((field) =>
            field.key === "name" ? (
              <div key="name" className="name-field">
                <label>
                  <span>Name(s)</span>
                  <textarea
                    rows={2}
                    value={draft.name}
                    onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  />
                </label>
                <NameSplit
                  name={draft.name}
                  onChange={(name) => setDraft({ ...draft, name })}
                />
              </div>
            ) : field.key === "status" ? (
              <div key="status" className="status-row">
                <label>
                  <span>Status</span>
                  <select
                    value={draft.status}
                    onChange={(e) => setDraft({ ...draft, status: e.target.value as LotStatus })}
                  >
                    <option>Occupied</option>
                    <option>Empty</option>
                    <option>Open</option>
                    <option>Eviction</option>
                  </select>
                </label>
                <label>
                  <span>Maintenance</span>
                  <input
                    value={draft.maintenance ?? ""}
                    placeholder="Leak"
                    onChange={(e) => setDraft({ ...draft, maintenance: e.target.value })}
                  />
                </label>
              </div>
            ) : (
            <label key={field.key}>
              <span>{field.label}</span>
              {field.key === "issues" ? (
                <textarea
                  rows={4}
                  value={draft.issues}
                  onChange={(e) => setDraft({ ...draft, issues: e.target.value })}
                />
              ) : (
                <input
                  value={String(draft[field.key] ?? "")}
                  onChange={(e) => setDraft({ ...draft, [field.key]: e.target.value })}
                />
              )}
            </label>
            ),
          )}
          <div className="edit-actions">
            <button className="edit-save" type="submit">
              Save
            </button>
            <button className="edit-cancel" type="button" onClick={() => setEditing(false)}>
              Cancel
            </button>
          </div>
        </form>
      </aside>
    );
  }
  return (
    <aside className="panel">
      <div className="panel-head">
        <p className="quiet sheet-where">{where ? `Map ${where}` : "Register only"}</p>
        <button
          className="edit-btn"
          type="button"
          onClick={() => {
            setDraft({ ...lot });
            setEditing(true);
          }}
        >
          Edit
        </button>
      </div>
      <dl className="record">
        {RECORD_FIELDS.slice(0, 6).map((field) => {
          const value = String(lot[field.key] ?? "");
          const blank = value.trim().length === 0;
          if (field.key === "status") {
            const maint = (lot.maintenance ?? "").trim();
            const leak = /^leak$/i.test(maint);
            return (
              <div key="status" className="status-row">
                <div>
                  <dt>Status</dt>
                  <dd className={`${field.cls}${blank ? " v-blank" : ""}${value === "Eviction" ? " eviction" : ""}${value === "Occupied" ? " occupied" : ""}`}>{blank ? "—" : value}</dd>
                </div>
                <div>
                  <dt>Maintenance</dt>
                  <dd className={maint ? (leak ? "v-leak" : "v-maint") : "v-blank"}>{maint || "—"}</dd>
                </div>
              </div>
            );
          }
          return (
            <div key={field.key}>
              <dt>{field.label}</dt>
              <dd className={`${field.cls}${blank ? " v-blank" : ""}`}>{blank ? "—" : value}</dd>
              {field.key === "name" ? <NameSplit name={lot.name} /> : null}
            </div>
          );
        })}
      </dl>
      <div className="record-grid">
        {RECORD_FIELDS.slice(6).map((field) => {
          const value = String(lot[field.key] ?? "");
          const blank = value.trim().length === 0;
          return (
            <div key={field.key} className={field.key === "bouncedCheck" ? "under-late" : undefined}>
              <dt>{field.label}</dt>
              <dd className={`${field.cls}${blank ? " v-blank" : ""}`}>{blank ? "—" : value}</dd>
            </div>
          );
        })}
      </div>
    </aside>
  );
}

function NameSplit({ name, onChange }: { name: string; onChange?: (name: string) => void }) {
  const parts = nameParts(name);
  return (
    <div className="name-split">
      <label>
        <span>First name</span>
        {onChange ? (
          <input
            value={parts.first}
            onChange={(e) => onChange(joinName(parts.last, e.target.value))}
          />
        ) : (
          <div className="name-box">{parts.first || "—"}</div>
        )}
      </label>
      <label>
        <span>Last name</span>
        {onChange ? (
          <input
            value={parts.last}
            onChange={(e) => onChange(joinName(e.target.value, parts.first))}
          />
        ) : (
          <div className="name-box">{parts.last || "—"}</div>
        )}
      </label>
    </div>
  );
}

const RECORD_FIELDS: { key: keyof Lot; label: string; cls: string }[] = [
  { key: "lot", label: "Lot", cls: "v-lot" },
  { key: "address", label: "Address", cls: "v-address" },
  { key: "street", label: "Street", cls: "v-street" },
  { key: "name", label: "Name(s)", cls: "v-name" },
  { key: "issues", label: "Issues", cls: "v-issues" },
  { key: "status", label: "Status", cls: "v-status" },
  { key: "renter", label: "Renter/Owner", cls: "v-renter" },
  { key: "rent", label: "Rental Amount", cls: "v-rent" },
  { key: "key", label: "Key", cls: "v-key" },
  { key: "phone", label: "Phone Number", cls: "v-phone" },
  { key: "email", label: "Email", cls: "v-email" },
  { key: "noMow", label: "No Mow", cls: "v-flag" },
  { key: "lateRent", label: "Late Rent", cls: "v-late" },
  { key: "bouncedCheck", label: "Bounced Check", cls: "v-flag" },
  { key: "guest", label: "Guest", cls: "v-guest" },
  { key: "vehicle", label: "Vehicle", cls: "v-vehicle" },
  { key: "acFilter", label: "A/C Filter", cls: "v-filter" },
  { key: "pressureWash", label: "Exterior Pressure Wash", cls: "v-wash" },
  { key: "violations", label: "Violations", cls: "v-violations" },
  { key: "washer", label: "Washer", cls: "v-washer" },
  { key: "dryer", label: "Dryer", cls: "v-dryer" },
];
